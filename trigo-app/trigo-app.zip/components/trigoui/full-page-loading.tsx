"use client"

import { TriGOLoading } from "./trigo-loading"

export function FullPageLoading() {
  return <TriGOLoading size={40} fullPage={true} />
}
